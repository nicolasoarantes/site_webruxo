import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/IngjYToW2o48jZ6F/scene.splinecode" 
      />
    </main>
  );
}
