import Spline from '@splinetool/react-spline/next';

export default function Home() {
  return (
    <main>
      <Spline
        scene="https://prod.spline.design/rpouiftbxrJqNDoc/scene.splinecode" 
      />
    </main>
  );
}
